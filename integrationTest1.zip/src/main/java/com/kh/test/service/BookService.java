package com.kh.test.service;

import java.awt.print.Book;
import java.util.List;

public interface BookService {

	List<Book> selectAllList();

}
